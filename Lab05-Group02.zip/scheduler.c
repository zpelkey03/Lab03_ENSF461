#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <limits.h>
#include <time.h>


// TODO: Add more fields to this struct
struct job {
    int id;
    int arrival;
    int start_time;
    int length;
    int tickets;
    int time_left;
    int completion_time;
    struct job *next;
};

/*** Globals ***/ 
int seed = 100;

//This is the start of our linked list of jobs, i.e., the job list
struct job *head = NULL;

/*** Globals End ***/

/*Function to append a new job to the list*/
void append(int id, int arrival, int length, int tickets){
  // create a new struct and initialize it with the input data
  struct job *tmp = (struct job*) malloc(sizeof(struct job));

  //tmp->id = numofjobs++;
  tmp->id = id;
  tmp->length = length;
  tmp->arrival = arrival;
  tmp->tickets = tickets;
  tmp->time_left = length;

  // the new job is the last job
  tmp->next = NULL;

  // Case: job is first to be added, linked list is empty 
  if (head == NULL){
    head = tmp;
    return;
  }

  struct job *prev = head;

  //Find end of list 
  while (prev->next != NULL){
    prev = prev->next;
  }

  //Add job to end of list 
  prev->next = tmp;
  return;
}


/*Function to read in the workload file and create job list*/
void read_workload_file(char* filename) {
  int id = 0;
  FILE *fp;
  size_t len = 0;
  ssize_t read;
  char *line = NULL,
       *arrival = NULL, 
       *length = NULL;
  int tickets = 0;

  struct job **head_ptr = malloc(sizeof(struct job*));
  
  if( (fp = fopen(filename, "r")) == NULL)
    exit(EXIT_FAILURE);
  
  
  while ((read = getline(&line, &len, fp)) > 1) {
    arrival = strtok(line, ",\n");
    length = strtok(NULL, ",\n");
    tickets += 100;
       
    // Make sure neither arrival nor length are null. 
    assert(arrival != NULL && length != NULL);
        
    append(id++, atoi(arrival), atoi(length), tickets);
  }

  fclose(fp);

  // Make sure we read in at least one job
  assert(id > 0);

  return;
}

struct job* findShortestRemainingTimeJob(struct job* head, int current_time) {
    struct job* shortest_job = NULL;
    int shortest_time_left = -1;

    struct job* current = head;
    while (current != NULL) {
        if (current->time_left > 0 && current->arrival <= current_time) {
            if (shortest_job == NULL || current->time_left < shortest_time_left) {
                shortest_job = current;
                shortest_time_left = current->time_left;
            }
        }
        current = current->next;
    }

    return shortest_job;
}

void policy_STCF(struct job *head, int slice) {
  int size = 0;
  //Get the number of total jobs
  struct job* current = head;
  while(current != NULL){
    size++;
    current = current->next;
  }

  int current_time = 0;
  while (size > 0){
    struct job* running_job = findShortestRemainingTimeJob(head, current_time);
    int arrived = current_time;
    int run_time;
    //One time check for start_time when current time is 0
    if (current_time == 0){
      running_job->start_time = 0;
    }
    //If there is a job to currently run
    if (running_job != NULL){
      //If theres more time left then the slice
      if ((running_job->time_left) > slice){
        //If its the jobs first time running
        if (running_job->start_time == 0 && running_job->time_left == running_job-> length) running_job->start_time = current_time; 
        //subtract the slice
        running_job->time_left -= slice;
        //increase current size
        current_time += slice; 
        //set run_time
        run_time = slice;
      }
      //If the time remaining is less than the slice
      else {
        //If it's the jobs first time running
        if (running_job->start_time == 0  &&  running_job->time_left == running_job-> length) running_job->start_time = current_time; 
        //Increase size by time left
        current_time += running_job->time_left;
        run_time = running_job->time_left;
        //set time left to 0
        running_job->time_left = 0;
        running_job->completion_time = current_time;
        //take one completed job off
        size--;
      }
      printf("t=%d: [Job %d] arrived at [%d], ran for: [%d]\n", current_time, running_job->id, arrived, run_time);
    }
    else{
      printf("t=%d: No Job waited for: [%d]\n", current_time, slice);
      current_time += slice;
    }
  }
  return;
}

void analyze_STCF(struct job *head) {
  int total_response_time = 0;
    int total_turnaround_time = 0;
    int total_wait_time = 0;
    int job_count = 0;

    struct job* current = head;

    while (current != NULL) {
        printf("Job %d -- Response time: %d  Turnaround: %d  Wait: %d\n", 
               current->id, current->start_time - current->arrival, current->completion_time - current->arrival, current->completion_time - current->arrival- current->length);
        
        total_response_time += current->start_time - current->arrival;
        total_turnaround_time += current->completion_time - current->arrival;
        total_wait_time +=  current->completion_time - current->arrival- current->length;
        job_count++;

        current = current->next;
    }

    float avg_response_time = (float)total_response_time / job_count;
    float avg_turnaround_time = (float)total_turnaround_time / job_count;
    float avg_wait_time = (float)total_wait_time / job_count;

    printf("Average -- Response: %.2f  Turnaround %.2f  Wait %.2f\n", 
           avg_response_time, avg_turnaround_time, avg_wait_time);
}

void policy_RR(struct job *head, int slice) {
  int size = 0;
  //Get the number of total jobs
  struct job* current = head;
  while(current != NULL){
    size++;
    current = current->next;
  }

  int current_time = 0;

  while (size > 0){
    struct job* current = head;
    int ranFlag = 0;
    //Goes through the jobs
     while (current != NULL) {
      int run_time;
      int arrived = current_time;
      //if the job is able to be ran
        if (current->time_left > 0 && current->arrival <= current_time) {
          ranFlag = 1;
        //One time check for start_time when current time is 0
        if ((current->time_left) > slice){
        //If its the jobs first time running
        if (current->start_time == 0 && current->time_left == current-> length) current->start_time = current_time; 
        //subtract the slice
        current->time_left -= slice;
        //increase current size
        current_time += slice; 
        //set run_time
        run_time = slice;
      }
      //If the time remaining is less than the slice
      else {
        //If it's the jobs first time running
        if (current->start_time == 0  &&  current->time_left == current-> length) current->start_time = current_time; 
        //Increase size by time left
        current_time += current->time_left;
        run_time = current->time_left;
        //set time left to 0
        current->time_left = 0;
        current->completion_time = current_time;
        //take one completed job off
        size--;
      }
        printf("t=%d: [Job %d] arrived at [%d], ran for: [%d]\n", current_time, current->id, current->arrival, run_time);
        }
        current = current->next;
     }
     if (size > 0 && ranFlag == 0){
      printf("t=%d: No Job, waited for: [%d]\n", current_time, slice);
      current_time += slice;
     }
  }
}

void analyze_RR(struct job* head){
  int total_response_time = 0;
    int total_turnaround_time = 0;
    int total_wait_time = 0;
    int job_count = 0;

    struct job* current = head;

    while (current != NULL) {
        printf("Job %d -- Response time: %d  Turnaround: %d  Wait: %d\n", 
               current->id, current->start_time - current->arrival, current->completion_time - current->arrival, current->completion_time - current->arrival- current->length);
        
        total_response_time += current->start_time - current->arrival;
        total_turnaround_time += current->completion_time - current->arrival;
        total_wait_time +=  current->completion_time - current->arrival- current->length;
        job_count++;

        current = current->next;
    }

    float avg_response_time = (float)total_response_time / job_count;
    float avg_turnaround_time = (float)total_turnaround_time / job_count;
    float avg_wait_time = (float)total_wait_time / job_count;

    printf("Average -- Response: %.2f  Turnaround %.2f  Wait %.2f\n", 
           avg_response_time, avg_turnaround_time, avg_wait_time);
}

int getRandomNumber(int max) {
    return 1 + rand() % (max);
}

void policy_LT(struct job* head, int slice){
    int size = 0;
  //Get the number of total jobs
  struct job* current = head;
  while(current != NULL){
    size++;
    current = current->next;
  }

  int current_time = 0;

  while (size > 0){
    struct job* current = head;
    int total_tickets = 0;
    //counts valid tickets
    while(current != NULL){
      //if the job is able to be ran
      if (current->time_left > 0 && current->arrival <= current_time) {
        total_tickets += current->tickets;
      }
      current = current->next;
    }

    int randomNum = getRandomNumber(total_tickets);
    //Get the winner
    while(current != NULL){
      int run_time;
      int arrived = current_time;
      //if the job is able to be ran
      if (current->time_left > 0 && current->arrival <= current_time){
        //Loser Case
        if (randomNum - current->tickets > 0){
          randomNum -= current->tickets;
        }
        //Winner Case
        else{
          //One time check for start_time when current time is 0
        if ((current->time_left) > slice){
        //If its the jobs first time running
        if (current->start_time == 0 && current->time_left == current-> length) current->start_time = current_time; 
        //subtract the slice
        current->time_left -= slice;
        //increase current size
        current_time += slice; 
        //set run_time
        run_time = slice;
        }
        //If the time remaining is less than the slice
        else {
        //If it's the jobs first time running
        if (current->start_time == 0  &&  current->time_left == current-> length) current->start_time = current_time; 
        //Increase size by time left
        current_time += current->time_left;
        run_time = current->time_left;
        //set time left to 0
        current->time_left = 0;
        current->completion_time = current_time;
        //take one completed job off
        size--;
        }
        printf("t=%d: [Job %d] arrived at [%d], ran for: [%d]\n", current_time, current->id, current->arrival, run_time);
        break;
        }
      }
      current = current->next;
    }
    //no jobs
    if (size > 0 && total_tickets == 0){
      printf("t=%d: No Job, waited for: [%d]\n", current_time, slice);
      current_time += slice;
    }
  }
}

void analyze_LT(struct job* head){}


int main(int argc, char **argv) {
 if (argc < 5) {
    fprintf(stderr, "missing variables\n");
    fprintf(stderr, "usage: %s analysis-flag policy workload-file slice-length\n", argv[0]);
		exit(EXIT_FAILURE);
  }

  int analysis = atoi(argv[1]);
  char *policy = argv[2],
       *workload = argv[3];
  int slice = atoi(argv[4]);

  // Note: we use a global variable to point to 
  // the start of a linked-list of jobs, i.e., the job list 
  read_workload_file(workload);
  
  if (strcmp(policy, "STCF") == 0 ) {
    policy_STCF(head, slice);
    if (analysis) {
      printf("Begin analyzing STCF:\n");
      analyze_STCF(head);
      printf("End analyzing STCF.\n");
    }

    exit(EXIT_SUCCESS);
  }

  // TODO: Add other policies 
  if (strcmp(policy, "RR") == 0 ) {
    policy_RR(head, slice);
    if (analysis) {
      printf("Begin analyzing RR:\n");
      analyze_RR(head);
      printf("End analyzing RR.\n");
    }

    exit(EXIT_SUCCESS);
  }

  if (strcmp(policy, "LT") == 0 ) {
    policy_LT(head, slice);
    if (analysis) {
      printf("Begin analyzing LT:\n");
      analyze_LT(head);
      printf("End analyzing LT.\n");
    }

    exit(EXIT_SUCCESS);
  }

	exit(EXIT_SUCCESS);
}
